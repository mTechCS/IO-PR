## Module <hr_payslip_monthly_report>

#### 05.11.2019
#### Version 12.0.1.0.1
##### FIX
- Bug Fixed
